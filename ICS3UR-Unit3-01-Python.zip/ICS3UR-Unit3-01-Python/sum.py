#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program calculates the sum of two numbers


def main():
    # calculates the sum of two numbers

    # input
    print("We will be calculating the sum of two numbers")
    numo = int(input("Enter a number: "))
    numt = int(input("Enter another number: "))

    # process
    sm = numo + numt

    # output
    print("")
    print("{0}+{1}={2}".format(numo, numt, sm))


if __name__ == "__main__":
    main()
